module.exports={
    getLoginInfo(){
        let loginInfo={
            "header":{
                "text":"当当登录"
            }
        };
        return loginInfo;
    }
};