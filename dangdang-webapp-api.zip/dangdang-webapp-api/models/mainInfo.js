module.exports={
    getMainInfo(){
        let mainInfo={
            "imgs":{
                "pic1":"http://59.110.229.146/images/main/icon_03_in-1536891748.png",
                "pic2":"http://59.110.229.146/images/imgs1/feilei-8-2.png",
                "pic3":"http://59.110.229.146/images/main/ic_buy_normal-1537519625.png",
                "pic4":"http://59.110.229.146/images/imgs1/guowuche-8-2.png",
                "pic5":"http://59.110.229.146/images/imgs1/wodedangdang---4.png"
            }
        };
        return mainInfo;
    }
};